
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# In[2]:



import types
import pandas as pd
from botocore.client import Config
import ibm_boto3

def __iter__(self): return 0

# @hidden_cell
# The following code accesses a file in your IBM Cloud Object Storage. It includes your credentials.
# You might want to remove those credentials before you share your notebook.
client_877f27b7b5804d6382532bb0ad668ac2 = ibm_boto3.client(service_name='s3',
    ibm_api_key_id='3celY2mhUGFkBgNdv5RJUFVwjYYKbgMa4SQnuYmj40WK',
    ibm_auth_endpoint="https://iam.bluemix.net/oidc/token",
    config=Config(signature_version='oauth'),
    endpoint_url='https://s3.eu-geo.objectstorage.service.networklayer.com')

body = client_877f27b7b5804d6382532bb0ad668ac2.get_object(Bucket='incomeprediction-donotdelete-pr-qdndjehrxcrszj',Key='income1.csv')['Body']
# add missing __iter__ method, so pandas accepts body as file-like object
if not hasattr(body, "__iter__"): body.__iter__ = types.MethodType( __iter__, body )

dataset= pd.read_csv(body)
dataset.head()



# In[3]:


dataset


# In[4]:


x=dataset.iloc[:,:-2]


# In[5]:


x=dataset.iloc[:,:-2].values


# In[6]:


x


# In[7]:


dataset.isnull().any()


# In[8]:


y=dataset.iloc[:,9]


# In[9]:


y=dataset.iloc[:,9].values


# In[10]:


y


# In[11]:


y.shape


# In[12]:


from sklearn.preprocessing import LabelEncoder 
lb=LabelEncoder()


# In[13]:


x


# In[14]:


lb1=LabelEncoder()
x[:,1]=lb1.fit_transform(x[:,1])


# In[15]:


x


# In[16]:


lb2=LabelEncoder()
x[:,2]=lb2.fit_transform(x[:,2])


# In[17]:


x


# In[18]:


x[[3]]


# In[19]:


lb3=LabelEncoder()
x[:,3]=lb3.fit_transform(x[:,3])


# In[20]:


x


# In[21]:


lb4=LabelEncoder()
x[:,4]=lb4.fit_transform(x[:,4])


# In[22]:


x


# In[23]:


y=lb.fit_transform(y)


# In[24]:


y


# In[30]:


x[0:1,0:]


# In[31]:


from sklearn.preprocessing import OneHotEncoder  #To simplify the binary values(numerical values)
oh=OneHotEncoder(categorical_features=[3]) #removes unwanted things
x=oh.fit_transform(x).toarray()


# In[33]:


x=x[:,1:]


# In[36]:


x[[0]]


# In[37]:


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 0)


# In[63]:


x_train.shape


# In[38]:


y_test


# In[40]:


y_train=y_train.flatten()


# In[41]:


from sklearn.ensemble import RandomForestClassifier


# In[42]:


classifier=RandomForestClassifier(n_estimators=10)
classifier.fit(x_train,y_train)


# In[43]:


y_pred  = classifier.predict(x_test)


# In[44]:


y_pred


# In[45]:


from sklearn.metrics import confusion_matrix
confusion_matrix(y_test,y_pred)


# In[46]:


from sklearn.metrics import accuracy_score
accuracy_score(y_test,y_pred)


# In[50]:


get_ipython().system(u'pip install watson-machine-learning-client --upgrade')


# In[51]:


from watson_machine_learning_client import WatsonMachineLearningAPIClient


# In[52]:


wml_credentials={
"apikey": "QVu_Bszegezxf01OLOFgMDV3l-4OlnSqQcdu-7S5HG0I",
"instance_id": "0482d021-52cd-4566-b9d7-54b41fd5965c",
"password": "5bf19efb-474b-4d8d-92ba-400bd38cd144",
"url": "https://eu-gb.ml.cloud.ibm.com",
"username": "5bf19efb-474b-4d8d-92ba-400bd38cd144"
}


# In[53]:


client = WatsonMachineLearningAPIClient(wml_credentials)
import json


# In[54]:


instance_details = client.service_instance.get_details()
print(json.dumps(instance_details, indent=2))


# In[55]:


model_props = {client.repository.ModelMetaNames.AUTHOR_NAME: "nithish", 
               client.repository.ModelMetaNames.AUTHOR_EMAIL: "modhenithish@gmail.com", 
               client.repository.ModelMetaNames.NAME: "Multi Linear"}


# In[57]:


model_artifact =client.repository.store_model(classifier, meta_props=model_props)


# In[58]:


published_model_uid = client.repository.get_model_uid(model_artifact)


# In[59]:


published_model_uid


# In[60]:


created_deployment = client.deployments.create(published_model_uid, name="multilinear")


# In[61]:


scoring_endpoint = client.deployments.get_scoring_url(created_deployment)
scoring_endpoint


# In[62]:


client.deployments.list()

